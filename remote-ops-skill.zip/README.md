# remote-ops

A Cursor Agent Skill that stops the agent from burning tokens on throwaway remote
debugging scripts.

## The problem

When an agent investigates a remote server, it typically writes a new script for every
lookup:

```
_ssh_probe.py   _ssh_index.py   _ssh_read.py
_pay_cfg.py     _pay_logs.py    _pay_flow.py   ... x50
```

Each of those bodies stays in the conversation context permanently and is re-sent on
every following step. Measured on a real session: **52 throwaway scripts accounted for
63% of total token cost**, and the session used roughly 3.6M input tokens in a single
thread.

## The fix

One persistent harness, called with short commands instead of generated scripts.
Measured effect on the same workload: **86% reduction** in script-related cost.

| Before | After |
|---|---|
| write `_ssh_probe.py`, run it, repeat | `rs prod --rg "pattern" /path` |
| write a script to cat a remote file | `rs prod --read /path -n 100` |
| write a script to upload a patch | `rs prod --put local.conf /remote/path` |

## Install

1. Copy this folder to your Cursor skills directory:

```
~/.cursor/skills/remote-ops/
├── SKILL.md
├── reference.md
└── harness-source.md
```

2. Create the harness from [harness-source.md](harness-source.md):

```
~/.cursor/tools/rs.py
```

3. Verify:

```bash
python ~/.cursor/tools/rs.py --list
```

4. Create `~/.cursor/tools/rs_hosts.json` with your own hosts, or skip it entirely if
   your machines are already in `~/.ssh/config` (they then work with no config).

## Usage

Ask the agent to use the skill, or let it load when a task involves ssh:

```
/remote-ops check why the service on prod won't start
```

The agent will use `rs <alias> -c "..."` style commands rather than writing scripts.

## What it includes

| File | Purpose |
|---|---|
| `SKILL.md` | Agent instructions: the rule, the discipline, the safety rails |
| `reference.md` | Host config, auth modes, troubleshooting, migration table |
| `harness-source.md` | Full source of `rs.py`, copy-paste installable |

## Design notes

- **Zero-config path.** Hosts already in `~/.ssh/config` work immediately, including
  keys, agent, `ProxyCommand`, and jump hosts. No JSON required.
- **No credentials in scripts.** Secrets live in one gitignored config file, never in
  generated code that ends up in chat history.
- **`-f` runs code without persisting it.** A local python file is piped to
  `python3 -u -` over stdin, so throwaway analysis leaves no trace on the remote box.
- **`paramiko` is optional.** Without it, the harness shells out to `ssh`/`scp`.

## Related discipline

The skill also encodes three habits that matter more than the harness itself:

1. One task per conversation (splitting saved 35-45% on the measured session).
2. Combine lookups into one command instead of a dozen probes (68% of shell calls in
   that session were under 120 characters, each a separate round trip).
3. Stop and report after ~15 unfruitful steps (one 70-step chain consumed 35% of the
   session).

## License

MIT. Use and modify freely.
