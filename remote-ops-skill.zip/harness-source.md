# The rs.py harness

This is the single file the skill drives. Create it once at:

```
~/.cursor/tools/rs.py
```

On Windows: `C:/Users/<you>/.cursor/tools/rs.py`

Copy everything in the block below into that path, then verify with:

```bash
python ~/.cursor/tools/rs.py --list
```

No other files are required. `paramiko` is optional: without it, hosts declared in
`~/.ssh/config` still work through the system `ssh` binary.

---

## Source

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""rs.py - one reusable remote-ops harness, meant to be shared by every project.

Install once at ~/.cursor/tools/rs.py, then call it instead of writing a new
throw-away script for each lookup. One-off script bodies stay in the chat
context permanently and get re-sent on every step, which is where most of the
token cost goes.

Modes
  rs.py <alias> -c "<shell command>"          run a remote shell command
  rs.py <alias> -f <local.py>                 run a local python3 file remotely
  rs.py <alias> --read <path> [-n 100]        print the head of a remote file
  rs.py <alias> --rg <pattern> <path>         grep -rn on a remote path
  rs.py <alias> --put <local> <remote>        upload a file
  rs.py <alias> --get <remote> <local>        download a file
  rs.py --list                                show aliases + active config
  rs.py <alias> ... --dry-run                 print the transport call, don't run

Host config (first match wins)
  %RS_HOSTS%                      explicit path
  ./.rs_hosts.json                per project, commit-free
  ~/.cursor/tools/rs_hosts.json   global fallback

  {"alias": {"host": "1.2.3.4", "user": "root", "password": "...", "port": 22},
   "alias2": {"host": "1.2.3.4", "user": "root", "key": "C:/path/id_ed25519"}}

An alias that is not in any config file falls back to system ssh/scp, so every
host already declared in ~/.ssh/config (keys, agent, ProxyCommand) works with
no extra config at all.
"""
import argparse
import json
import os
import subprocess
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

GLOBAL_CONFIG = os.path.join(os.path.expanduser("~"), ".cursor", "tools", "rs_hosts.json")


def config_candidates():
    """Paths searched, in priority order. Kept for reference/debugging."""
    return [
        os.environ.get("RS_HOSTS"),
        os.path.join(os.getcwd(), ".rs_hosts.json"),
        GLOBAL_CONFIG,
    ]


def config_path():
    explicit = os.environ.get("RS_HOSTS")
    if explicit:
        # an explicit override that does not exist is a mistake, not a fallback
        if not os.path.isfile(explicit):
            sys.exit("RS_HOSTS is set to %r but that file does not exist" % explicit)
        return explicit
    for p in (os.path.join(os.getcwd(), ".rs_hosts.json"), GLOBAL_CONFIG):
        if os.path.isfile(p):
            return p
    return None


def load_hosts():
    p = config_path()
    if not p:
        return {}, None
    try:
        # utf-8-sig: tolerate the BOM that PowerShell / Notepad add
        with open(p, encoding="utf-8-sig") as f:
            return json.load(f), p
    except Exception as e:
        sys.exit("bad config %s: %s" % (p, e))


def shquote(s):
    return "'" + s.replace("'", "'\\''") + "'"


# ---------------------------------------------------------------- transports

def _run_paramiko(cfg, command=None, script=None, timeout=90):
    import paramiko

    kw = dict(
        hostname=cfg["host"],
        port=int(cfg.get("port", 22)),
        username=cfg.get("user", "root"),
        timeout=int(cfg.get("connect_timeout", 15)),
        allow_agent=False,
        look_for_keys=False,
    )
    if cfg.get("key"):
        kw["key_filename"] = os.path.expanduser(cfg["key"])
        kw["allow_agent"] = True
        kw["look_for_keys"] = True
    elif cfg.get("password"):
        kw["password"] = cfg["password"]
    else:
        kw["allow_agent"] = True
        kw["look_for_keys"] = True

    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(**kw)
    try:
        if script is not None:
            cmd = "python3 -u - <<'PYEOF'\n" + script.lstrip("\ufeff") + "\nPYEOF"
        else:
            cmd = command
        _in, out, err = c.exec_command(cmd, timeout=timeout)
        o = out.read().decode("utf-8", "replace")
        e = err.read().decode("utf-8", "replace")
        if e.strip():
            sys.stderr.write(e)
        return o
    finally:
        c.close()


def _ssh_argv(cfg, alias):
    if cfg is None:
        return ["ssh", "-o", "BatchMode=yes", alias]
    argv = ["ssh"]
    if cfg.get("port"):
        argv += ["-p", str(cfg["port"])]
    if cfg.get("key"):
        argv += ["-i", os.path.expanduser(cfg["key"])]
    argv += ["%s@%s" % (cfg.get("user", "root"), cfg["host"])]
    return argv


def _run_system_ssh(cfg, alias, command=None, script=None, timeout=90):
    argv = _ssh_argv(cfg, alias)
    if script is not None:
        argv += ["python3 -u -"]
        payload = script.encode("utf-8")
    else:
        argv += [command]
        payload = None
    r = subprocess.run(argv, input=payload, capture_output=True, timeout=timeout)
    o = r.stdout.decode("utf-8", "replace")
    e = r.stderr.decode("utf-8", "replace")
    if e.strip():
        sys.stderr.write(e)
    return o


def run_remote(cfg, alias, command=None, script=None, timeout=90):
    if cfg is not None and (cfg.get("password") or cfg.get("key")):
        return _run_paramiko(cfg, command=command, script=script, timeout=timeout)
    return _run_system_ssh(cfg, alias, command=command, script=script, timeout=timeout)


def transfer(cfg, alias, local, remote, upload=True):
    src, dst = (local, remote) if upload else (remote, local)
    verb = "put" if upload else "get"
    if cfg is not None and cfg.get("password") and not cfg.get("key"):
        import paramiko

        t = paramiko.Transport((cfg["host"], int(cfg.get("port", 22))))
        t.connect(username=cfg.get("user", "root"), password=cfg["password"])
        try:
            sftp = paramiko.SFTPClient.from_transport(t)
            if upload:
                sftp.put(local, remote)
            else:
                sftp.get(remote, local)
            sftp.close()
        finally:
            t.close()
        return "%s %s -> %s\n" % (verb, src, dst)

    argv = ["scp"]
    if cfg is not None and cfg.get("port"):
        argv += ["-P", str(cfg["port"])]
    if cfg is not None and cfg.get("key"):
        argv += ["-i", os.path.expanduser(cfg["key"])]
    target = alias if cfg is None else "%s@%s" % (cfg.get("user", "root"), cfg["host"])
    argv += ([local, "%s:%s" % (target, remote)] if upload
             else ["%s:%s" % (target, remote), local])
    r = subprocess.run(argv, capture_output=True, timeout=600)
    if r.returncode:
        sys.exit(r.stderr.decode("utf-8", "replace"))
    return "%s %s -> %s\n" % (verb, src, dst)


# --------------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("alias", nargs="?")
    ap.add_argument("-c", "--command")
    ap.add_argument("-f", "--file")
    ap.add_argument("--read")
    ap.add_argument("-n", "--lines", type=int, default=100)
    ap.add_argument("--rg", nargs=2, metavar=("PATTERN", "PATH"))
    ap.add_argument("--put", nargs=2, metavar=("LOCAL", "REMOTE"))
    ap.add_argument("--get", nargs=2, metavar=("REMOTE", "LOCAL"))
    ap.add_argument("-t", "--timeout", type=int, default=90)
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    hosts, where = load_hosts()

    if a.list or not a.alias:
        print("config:", where or "(none - system ssh only)")
        if not hosts:
            print("aliases: none")
        for name, cfg in sorted(hosts.items()):
            auth = "password" if cfg.get("password") else ("key" if cfg.get("key") else "agent")
            print("  %-14s %s@%s:%s  [%s]  %s" % (
                name, cfg.get("user", "root"), cfg.get("host"),
                cfg.get("port", 22), auth, cfg.get("note", "")))
        print("\nsystem ssh hosts also work: see ~/.ssh/config")
        return

    cfg = hosts.get(a.alias)
    if a.dry_run:
        print("alias :", a.alias)
        print("config:", where or "(none)")
        print("route :", "paramiko" if (cfg and (cfg.get("password") or cfg.get("key")))
              else "system ssh/scp")
        if cfg:
            print("target:", "%s@%s:%s" % (cfg.get("user", "root"), cfg["host"], cfg.get("port", 22)))
        return

    if a.put or a.get:
        if a.put:
            local, remote = a.put
        else:
            remote, local = a.get
        sys.stdout.write(transfer(cfg, a.alias, local, remote, upload=bool(a.put)))
        return

    if a.file:
        script = open(a.file, encoding="utf-8").read()
        sys.stdout.write(run_remote(cfg, a.alias, script=script, timeout=a.timeout))
        return

    if a.command:
        cmd = a.command
    elif a.read:
        cmd = ("head -n %d %s" % (a.lines, shquote(a.read))) if a.lines else ("cat %s" % shquote(a.read))
    elif a.rg:
        pat, path = a.rg
        cmd = "grep -rn --color=never %s %s | head -n 60" % (shquote(pat), shquote(path))
    else:
        sys.exit("need one of -c / -f / --read / --rg / --put / --get")

    sys.stdout.write(run_remote(cfg, a.alias, command=cmd, timeout=a.timeout))


if __name__ == "__main__":
    main()
```

---

After saving, confirm the file is valid Python before relying on it:

```bash
python -c "import py_compile,sys; py_compile.compile(sys.argv[1], doraise=True)" ~/.cursor/tools/rs.py
```

Expected output: none (a compile error would raise).
