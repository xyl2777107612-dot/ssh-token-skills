---
name: remote-ops
description: Run remote server operations (ssh, grep, read config, upload/download files) through a reusable harness instead of generating throwaway scripts. Use when connecting to remote servers, inspecting remote files or logs, debugging on a staging or production box, or whenever a task involves ssh, paramiko, sftp, or scp.
disable-model-invocation: true
---

# Remote Ops

Remote investigation is the most token-expensive thing an agent does, because every
file it writes stays in the conversation context forever and gets re-sent on every
subsequent step. This skill enforces the cheap pattern: one reusable harness, short
commands, few steps.

## The rule

Never write a new script file to do a remote lookup. Every lookup is a short command
against a harness that is already installed.

```
rs <alias> -c "<remote shell command>"
rs <alias> --read <remote path> [-n 100]
rs <alias> --rg <pattern> <remote path>
rs <alias> -f <local.py>
rs <alias> --put <local> <remote>
rs <alias> --get <remote> <local>
rs --list
```

On Windows the full form is `python -W ignore C:\Users\<you>\.cursor\tools\rs.py ...`.

Check what is installed before the first call:

```bash
python ~/.cursor/tools/rs.py --list
```

If the harness is missing, see [reference.md](reference.md) for the setup section
before continuing. Do not fall back to generating one-off scripts.

## Why this matters

Measured on a real session: 52 `Write` calls of throwaway scripts accounted for 63%
of total token cost, because each script body was re-sent on every later step. Moving
to a single harness cut that portion by 86%.

The cost model:

- Each step re-sends the entire history, so content written early is paid for many times.
- A 1 KB script written at step 5 of a 145-step session costs roughly 1 KB x 140 steps.
- Short commands cost the same per call but add almost nothing to history.

## Working discipline

- **One task per conversation.** Unrelated tasks in one thread inherit each other's
  dirty context. Splitting saved 35-45% in the same session.
- **Combine lookups.** Chain related commands with `;` or `&&` in one call instead of
  probing with a dozen separate calls. 68% of shell calls in that session were under
  120 characters, each a separate round trip.
- **Stop and report.** If a single lookup chain passes ~15 steps and the answer is still
  not found, stop: report what was tried, what was learned, and what to verify next.
  One 70-step investigation consumed 35% of the whole session.
- **Back up before editing.** `cp file file.bak.$(date +%s)` before modifying anything
  on a remote box. Never edit production config without a way back.

## Safety

- Never hardcode credentials in a script. They end up in the conversation, in scrollback,
  and in any file that gets committed.
- Keep host config out of version control: add `.rs_hosts.json` to `.gitignore`.
- Prefer key-based auth. Password auth works but stores secrets in plaintext on disk.
- Confirm before destructive remote commands: `rm -rf`, `DROP`, `UPDATE` without `WHERE`,
  service restarts, config writes.

## Typical workflow

```
# 1. Orient: what is actually on the box
rs prod -c "hostname; uptime; ls -la /opt"

# 2. Narrow with a single grep instead of reading whole files
rs prod --rg "listen_port" /opt/app/config

# 3. Read only the region you need
rs prod --read /opt/app/config/app.conf -n 60

# 4. Pull a log slice instead of the whole file
rs prod -c "tail -n 200 /var/log/app/error.log"

# 5. Only now, if a local script is genuinely needed, run it remotely without saving it
rs prod -f ./analyze.py
```

## Reference

- Host configuration, auth modes, and the system-ssh fallback: [reference.md](reference.md)
- Troubleshooting and migration from throwaway scripts: [reference.md](reference.md)
