# Remote Ops reference

## Setup

The harness is a single Python file placed once at `~/.cursor/tools/rs.py`.

Requirements:

- Python 3.8+
- `paramiko` only if you use password or key auth through the harness

```bash
pip install paramiko
```

If `paramiko` is absent and the host is already in `~/.ssh/config`, the harness falls
back to the system `ssh` / `scp` binaries and never needs `paramiko` at all. This is
the simplest setup and is recommended.

```bash
python ~/.cursor/tools/rs.py --list
```

## Host configuration

Aliases are resolved in this order, first match wins:

1. `RS_HOSTS` environment variable pointing at a JSON file
2. `./.rs_hosts.json` in the current working directory (per project)
3. `~/.cursor/tools/rs_hosts.json` (global fallback)

`RS_HOSTS` is strict: if it is set but points at a missing file, the harness exits with
an error instead of silently falling through. That catches typo'd paths, which would
otherwise look like "my config isn't being picked up".

An alias found in none of these falls back to the system `ssh`, so anything already
declared in `~/.ssh/config` works with no configuration at all, including keys, agent,
`ProxyCommand`, and jump hosts.

### Zero-config: use ~/.ssh/config

If the machine is already reachable with plain `ssh myalias`, nothing else is needed:

```
rs myalias -c "hostname"
```

### Password or explicit key auth

`.rs_hosts.json`:

```json
{
  "prod": {
    "host": "10.0.0.5",
    "user": "root",
    "password": "REPLACE_ME",
    "note": "primary app server"
  },
  "stage": {
    "host": "10.0.0.6",
    "user": "deploy",
    "key": "C:/Users/me/.ssh/id_ed25519",
    "port": 2222,
    "note": "staging, non-standard port"
  }
}
```

Supported keys: `host`, `user`, `password`, `key`, `port`, `connect_timeout`, `note`.

Transport selection:

| Config has | Transport used |
|---|---|
| `password` | paramiko with password |
| `key` | paramiko with key file |
| neither, or alias unknown | system `ssh` / `scp` |

The file may be UTF-8 with a BOM; both are accepted.

## Commands

| Task | Command |
|---|---|
| Run a shell command | `rs <alias> -c "cmd1; cmd2"` |
| Read the head of a file | `rs <alias> --read /path -n 100` |
| Grep a file or tree | `rs <alias> --rg "pattern" /path` |
| Run a local python file remotely | `rs <alias> -f local.py` |
| Upload | `rs <alias> --put local.txt /remote/path` |
| Download | `rs <alias> --get /remote/path local.txt` |
| List configured aliases | `rs --list` |
| Show transport without executing | `rs <alias> --dry-run` |
| Extend the timeout | add `-t 180` |

`-f` sends the file over stdin to `python3 -u -` and does not persist anything on the
remote box. That keeps throwaway analysis code out of the remote filesystem and out of
the local repository.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `unknown host 'x'` | alias not in any config and not in `~/.ssh/config` | add it to `.rs_hosts.json` or `~/.ssh/config` |
| `RS_HOSTS is set to ... but that file does not exist` | env var points at a typo'd or moved path | fix or unset `RS_HOSTS` |
| `bad config ... Unexpected UTF-8 BOM` | very old harness version | upgrade the script, it now reads `utf-8-sig` |
| `ModuleNotFoundError: paramiko` | password/key auth configured but paramiko missing | `pip install paramiko`, or switch to key auth in `~/.ssh/config` so system ssh is used |
| Command hangs | remote process waiting on stdin or a long job | add `-t`, or run with `nohup ... &` |
| Output truncated | long output | narrow with `--rg`, `-n`, or `tail -n` |
| Chinese/CJK output garbled on Windows | console code page | the harness forces UTF-8; if still garbled set `chcp 65001` |

## Migrating from throwaway scripts

A common anti-pattern looks like this: 50 near-identical files, each with the same
connection boilerplate around a few lines of actual work.

```
_ssh_probe.py       _ssh_read.py      _pay_cfg.py
_ssh_index.py       _pay_logs.py      _pay_flow.py  ...
```

Each of those bodies stays in the conversation context permanently. The migration:

| Throwaway script | Replacement |
|---|---|
| `cat` a remote file, writing output to a local temp file | `rs <alias> --read /path -n 100` |
| grep on the remote box | `rs <alias> --rg "pattern" /path` |
| a script that connects and runs `python3 - <<EOF` | `rs <alias> -c "..."` or `rs <alias> -f x.py` |
| a script that uploads a patched config | `rs <alias> --put local.conf /remote/path` |
| a script that copies a log down for analysis | `rs <alias> --get /var/log/app.log ./` |

Only keep a real file when the tool is genuinely reused across sessions.
